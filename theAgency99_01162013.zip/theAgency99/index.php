<!DOCTYPE HTML>
<html>
<head>
<meta charset="UTF-8">
<title>Agency99</title>
<link href="main.css" rel="stylesheet" type="text/css">
<script src="modernizr-1.6.min.js"></script>
<script src="jquery-1.8.3.min.js"></script>
<!--Here is the script for the canvas animation -->
<script type="text/javascript">

window.addEventListener('load', eventWindowLoaded, false);	
function eventWindowLoaded() {

	canvasApp();
	
}

function canvasSupport () {
  	return Modernizr.canvas;
}


function canvasApp(){
	

	if (!canvasSupport()) {
			 return;
  	}else{
	    var theCanvas = document.getElementById('canvas');
	    var context = theCanvas.getContext('2d');
		
		var theCanvas2 = document.getElementById('canvas2');
		var context2 = theCanvas2.getContext('2d');
		
		var theCanvas2b = document.getElementById('canvas2b');
		var context2b = theCanvas2b.getContext('2d');
		
		var theCanvas2c = document.getElementById('canvas2c');
		var context2c = theCanvas2c.getContext('2d');
		
		var theCanvas2d = document.getElementById('canvas2d');
		var context2d = theCanvas2d.getContext('2d');
		
		var theCanvas2e = document.getElementById('canvas2e');
		var context2e = theCanvas2e.getContext('2d');
		
		var theCanvas2f = document.getElementById('canvas2f');
		var context2f = theCanvas2f.getContext('2d');
		
		var theCanvas2g = document.getElementById('canvas2g');
		var context2g = theCanvas2g.getContext('2d');
		
		var theCanvas2h = document.getElementById('canvas2h');
		var context2h = theCanvas2h.getContext('2d');
		
		var theCanvas2i = document.getElementById('canvas2i');
		var context2i = theCanvas2i.getContext('2d');
		
		var theCanvas2j = document.getElementById('canvas2j');
		var context2j = theCanvas2j.getContext('2d');
		
		var theCanvasN = document.getElementById('canvasN');
		var contextN = theCanvasN.getContext('2d');
		
		var theCanvasN2 = document.getElementById('canvasN2');
		var contextN2 = theCanvasN2.getContext('2d');
		
		var theCanvasN3 = document.getElementById('canvasN3');
		var contextN3 = theCanvasN3.getContext('2d');
		
		var theCanvasN4 = document.getElementById('canvasN4');
		var contextN4 = theCanvasN4.getContext('2d');
	}
	
	var mouseX;
	var mouseY;
	var tile_2;
	
	
	var tileSheet=new Image();
	tileSheet.addEventListener('load', eventSheetLoaded , false);
	//tileSheet.src="tanks_sheet.png";
	tileSheet.src="puzzle_maze_pieces.png";
	
	var tileSheet2 =new Image();
	tileSheet2.addEventListener('load', eventSheetLoaded , false);
	//tileSheet.src="tanks_sheet.png";
	tileSheet2.src="side_tiles.png";
	
	var tileSheetN =new Image();
	tileSheetN.addEventListener('load', eventSheetLoaded , false);
	//tileSheet.src="tanks_sheet.png";
	tileSheetN.src="puzzle_maze_numpad.png";

	
	
	//var imageData=context2.createImageData(32,32);
	
	function eventSheetLoaded() {
		startUp();
	}

	function startUp(){
		context.fillStyle="#aaaaaa";
		context.fillRect(0,0,267,333);
		
		//context2.fillStyle="#aaaaaa";
		//context2.fillRect(0,0,90,333);
		
		drawTileSheet();
		drawTileSheet2();
		drawTileSheet2b();
		drawTileSheet2c();
		drawTileSheet2d();
		drawTileSheet2e();
		drawTileSheet2f();
		drawTileSheet2g();
		drawTileSheet2h();
		drawTileSheet2i();
		drawTileSheet2j();
		drawTileSheetN();
		drawTileSheetN2();
		drawTileSheetN3();
		drawTileSheetN4();
	}
	
	function drawTileSheet(){
		context.drawImage(tileSheet, 0, 0);
		
	}
	
	function drawTileSheet2() {
		context2.drawImage(tileSheet2, 89, 0, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2b() {
		context2b.drawImage(tileSheet2, 178, 0, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2c() {
		context2c.drawImage(tileSheet2, 0, 83, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2d() {
		context2d.drawImage(tileSheet2, 89, 83, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2e() {
		context2e.drawImage(tileSheet2, 178, 83, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2f() {
		context2f.drawImage(tileSheet2, 0, 167, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2g() {
		context2g.drawImage(tileSheet2, 89, 167, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2h() {
		context2h.drawImage(tileSheet2, 178, 167, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2i() {
		context2i.drawImage(tileSheet2, 0, 250, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheet2j() {
		context2j.drawImage(tileSheet2, 89, 250, 89, 83, 0, 0, 89/2, 83/2);
	}
	
	function drawTileSheetN() {
		contextN.drawImage(tileSheetN, 0, 83, 89, 83, 0, 0, 89, 83);	
	}
	
	function drawTileSheetN2() {
		contextN2.drawImage(tileSheetN, 89, 83, 89, 83, 0, 0, 89, 83);	
	}
	
	function drawTileSheetN3() {
		contextN3.drawImage(tileSheetN, 89, 167, 89, 83, 0, 0, 89, 83);	
	}
	
	function drawTileSheetN4() {
		contextN4.drawImage(tileSheetN, 178, 167, 86, 83, 0, 0, 89, 83);	
	}
	
	/*function highlightTile(tileId,x,y){
		context.fillStyle="#aaaaaa";
		context.fillRect(0,0,256,128);
		drawTileSheet();
		
		imageData=context.getImageData(x,y,32,32);
		//loop through imageData.data. Set every 4th value to a new value
		for (j=3; j< imageData.data.length; j+=4){
			imageData.data[j]=128;
		}
		
		
		var startX=Math.floor(tileId % 8) *32;
		var startY=Math.floor(tileId / 8) *32;
		context.strokeStyle="red";
		context.strokeRect(startX,startY,32,32)
	}*/
	
	function onMouseMove(e) {
		//mouseX=e.clientX-theCanvas.offsetLeft;
		//mouseY=e.clientY-theCanvas.offsetTop;
	      
	}
	
	function onMouseClick(e) {
		/*console.log("click: " + mouseX + "," + mouseY);
		if (mouseY < 128){
			//find tile to highlight
			var col=Math.floor(mouseX / 32);
			var row=Math.floor(mouseY / 32)
			var tileId=(row*7)+(col+row);
			highlightTile(tileId,col*32,row*32)
		}else{
			var col=Math.floor(mouseX / 32);
			var row=Math.floor(mouseY / 32)*/
			
			
			
			
		//}
	}
	
	theCanvas.addEventListener("mousemove", onMouseMove, false);
	theCanvas.addEventListener("click", onMouseClick, false);


}

//**************Begin Tile Sheet Puzzle************************
/*window.addEventListener('load', eventWindowLoaded, false);	
function eventWindowLoaded() {

	canvasApp();
	
}

function canvasSupport () {
  	return Modernizr.canvas;
}


function canvasApp(){
	

	if (!canvasSupport()) {
			 return;
  	}else{
	    var theCanvas = document.getElementById('canvas');
	    var context = theCanvas.getContext('2d');
	}
	
	var mouseX;
	var mouseY;
	
	
	var tileSheet=new Image();
	tileSheet.addEventListener('load', eventSheetLoaded , false);
	//tileSheet.src="tanks_sheet.png";
	tileSheet.src="puzzle_maze_pieces.png";
	
	
	var imageData=context.createImageData(32,32);
	
	function eventSheetLoaded() {
		startUp();
	}

	function startUp(){
		context.fillStyle="#aaaaaa";
		context.fillRect(0,0,256,256);
		drawTileSheet();
	}
	
	function drawTileSheet(){
		context.drawImage(tileSheet, 0, 0);
		
	}
	
	function highlightTile(tileId,x,y){
		context.fillStyle="#aaaaaa";
		context.fillRect(0,0,256,128);
		drawTileSheet();
		
		imageData=context.getImageData(x,y,32,32);
		//loop through imageData.data. Set every 4th value to a new value
		for (j=3; j< imageData.data.length; j+=4){
			imageData.data[j]=128;
		}
		
		
		var startX=Math.floor(tileId % 8) *32;
		var startY=Math.floor(tileId / 8) *32;
		context.strokeStyle="red";
		context.strokeRect(startX,startY,32,32)
	}
	
	function onMouseMove(e) {
		mouseX=e.clientX-theCanvas.offsetLeft;
		mouseY=e.clientY-theCanvas.offsetTop;
	      
	}
	
	function onMouseClick(e) {
		console.log("click: " + mouseX + "," + mouseY);
		if (mouseY < 128){
			//find tile to highlight
			var col=Math.floor(mouseX / 32);
			var row=Math.floor(mouseY / 32)
			var tileId=(row*7)+(col+row);
			highlightTile(tileId,col*32,row*32)
		}else{
			var col=Math.floor(mouseX / 32);
			var row=Math.floor(mouseY / 32)
			
			context.putImageData(imageData,col*32,row*32);
			
			
		}
	}
	
	theCanvas.addEventListener("mousemove", onMouseMove, false);
	theCanvas.addEventListener("click", onMouseClick, false);


}**********************End *************************/


</script> 
<!--End Canvas Script -->


</head>

<body>

<div id="wrapper">
  
<nav >

<ul>
<li class="btn_home" ></li>
<li class="btn_mission" id="mission"></li>
<li class="btn_training" ></li>
<li class="btn_vehicles"></li>
<li class="btn_locations" id="locations"></li>
</ul>
<img class="mbox"src="buttons/metalbox.png" >


</nav>

<section>
<!--This is the main puzzle canvas -->

<canvas id="canvas" width="267" height="333"  style="position: absolute; top: 65px; left: 300px; border:outset; border-width:thick; border-color:#363; z-index:1;">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<!--These are the side canvases -->
<canvas id="canvas2" width="45" height="42"  style="position: absolute; top: 20px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2b" width="45" height="42"  style="position: absolute; top: 85px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2c" width="45" height="42"  style="position: absolute; top: 150px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2d" width="45" height="42"  style="position: absolute; top: 215px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2e" width="45" height="42"  style="position: absolute; top: 280px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2f" width="45" height="42"  style="position: absolute; top: 345px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2g" width="45" height="42"  style="position: absolute; top: 410px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2h" width="45" height="42"  style="position: absolute; top: 475px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2i" width="45" height="42"  style="position: absolute; top: 540px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvas2j" width="45" height="42"  style="position: absolute; top: 605px; left: 680px; border:groove; border-color:#363; z-index:1">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<!--These are the canvases for the three valid number keys -->
<canvas id="canvasN" width="90" height="83"  style="position: absolute; top: 150px; left: 306px; border:thin; z-index:2">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvasN2" width="90" height="83"  style="position: absolute; top: 150px; left: 395px; border:thin; z-index:2">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvasN3" width="90" height="83"  style="position: absolute; top: 233px; left: 395px; border:thin; z-index:2">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

<canvas id="canvasN4" width="86" height="83"  style="position: absolute; top: 233px; left: 485px; border:thin; z-index:2">
 Your browser does not support the HTML 5 Canvas. 
</canvas>

</section>

<section id="mdoor">
<script>
$("#canvas").hide();
$("#canvas2").hide();
$("#canvas2b").hide();
$("#canvas2c").hide();
$("#canvas2d").hide();
$("#canvas2e").hide();
$("#canvas2f").hide();
$("#canvas2g").hide();
$("#canvas2h").hide();
$("#canvas2i").hide();
$("#canvas2j").hide();
$("#canvasN").hide();
$("#canvasN2").hide();
$("#canvasN3").hide();
$("#canvasN4").hide();
$("#mdoor").hide();
</script>

<form name="input" action="mission4.html" method="get">
Password: <input type="text" name="user">
<input type="Submit" value="submit">
</form>
<!--<img class="nmaze" src="images/Number-Maze.png">-->
<!--<div class="nmaze"> &nbsp;</div>-->
<!--<img id="lockdwn" src="images/metaldoor2.png" >-->


<script>
//$("button").click(function(){
//$("#mdoor").hide();
var lockdoor = "";
$(document).ready(function(){
$("#mission").click(function(){
    $("#mdoor").slideToggle("slow");
	$("#canvas").fadeToggle("slow");
	$("#canvas2").fadeToggle("slow");
	$("#canvas2b").fadeToggle("slow");
	$("#canvas2c").fadeToggle("slow");
	$("#canvas2d").fadeToggle("slow");
	$("#canvas2e").fadeToggle("slow");
	$("#canvas2f").fadeToggle("slow");
	$("#canvas2g").fadeToggle("slow");
	$("#canvas2h").fadeToggle("slow");
	$("#canvas2i").fadeToggle("slow");
	$("#canvas2j").fadeToggle("slow");
	$("#canvasN").fadeOut("slow");
	$("#canvasN2").fadeOut("slow");
	$("#canvasN3").fadeOut("slow");
	$("#canvasN4").fadeOut("slow");	
  });
});

$(document).ready(function() {
    $("#locations").click(function() {
		document.location.href="mission_map.html";
	});
});

$(document).ready(function() {
    $("#canvas2c").click(function() {
		$("#canvasN").fadeToggle("slow");

	});
});

$(document).ready(function() {
    $("#canvas2d").click(function() {
		$("#canvasN2").fadeToggle("slow");

	});
});

$(document).ready(function() {
    $("#canvas2g").click(function() {
		$("#canvasN3").fadeToggle("slow");

	});
});

$(document).ready(function() {
    $("#canvas2h").click(function() {
		$("#canvasN4").fadeToggle("slow");

	});
});


 </script>
 <!--Here is the script for the canvas animation -->
<!--End Canvas Script -->

 
 </section>

</div>
</body>
</html>
